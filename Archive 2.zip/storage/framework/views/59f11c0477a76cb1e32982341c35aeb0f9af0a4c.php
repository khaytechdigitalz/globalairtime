<div class="card">
    <h6 class="card-header">
        <?php echo app('translator')->get('Registration History'); ?>
    </h6>

    <div class="card-body">
        <div class="pt-4 px-3">
            <canvas id="myChart" height="365"></canvas>
        </div>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/plugins/dashboard/widgets/registration-history.blade.php ENDPATH**/ ?>