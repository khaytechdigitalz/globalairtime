<?php if($socialProviders): ?>
    <?php $colSize = 12 / count($socialProviders); ?>

    <div class="row pb-3 pt-2">
        <?php if(in_array('facebook', $socialProviders)): ?>
        <div class="reg-google">
            <a href="<?php echo e(url('auth/facebook/login')); ?>"><i class="fab fa-facebook"></i>Log in with Google</a>
        </div> 
        <?php endif; ?>

        <?php if(in_array('twitter', $socialProviders)): ?>
        <div class="reg-google">
            <a href="<?php echo e(url('auth/twitter/login')); ?>"><i class="fab fa-twitter"></i>Log in with Google</a>
        </div> 
        <?php endif; ?>

        <?php if(in_array('google', $socialProviders)): ?>
        <div class="reg-google">
            <a href="<?php echo e(url('auth/google/login')); ?>"><i class="fab fa-google"></i>Log in with Google</a>
        </div> 
        <?php endif; ?>
    </div>

<?php endif; ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/auth/social/buttons.blade.php ENDPATH**/ ?>