<?php $__env->startSection('page-title', __('Add User')); ?>
<?php $__env->startSection('page-heading', __('Create New User')); ?>
 

<?php $__env->startSection('content'); ?>


    <!-- Dashboard Section start -->
    <section class="dashboard-section body-collapse pay step exchange">
        <div class="overlay pt-120">
            <div class="container-fruid">
                <div class="main-content">
                    <div class="head-area d-flex align-items-center justify-content-between">
                        <h4>Add New User</h4>
                        <div class="icon-area">
                            <img src="<?php echo e(url('public/backend/images/icon/support-icon.png')); ?>" alt="icon">
                        </div>
                    </div>

                    <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="row">
                        <div class="col-xl-12 col-lg-12">
                            <div class="choose-recipient">
                                 
                                 
                                <div class="tab-content">
                                    <div class="" id="recipients" role="tabpanel" aria-labelledby="recipients-tab">
                                        <div class="section-head">
                                            <h5>Add a new recipient</h5>
                                            <p>Please fill the form below to add new user.</p>
                                        </div>
                                        <?php echo Form::open(['route' => 'users.store', 'files' => true, 'id' => 'user-form']); ?>

                                        <?php echo $__env->make('user.partials.details', ['edit' => false, 'profile' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        
                                        <?php echo $__env->make('user.partials.auth', ['edit' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        <div class="col-12">
                                            <div class="footer-area mt-40">
                                                <button type="submit" class="cmn-btn w-100"> <?php echo app('translator')->get('Create User'); ?></button>
                                            </div>
                                        </div>
                                            <?php echo Form::close(); ?>

                                        </div>
                                     
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    </section>
    <!-- Dashboard Section end -->
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo HTML::script('assets/js/as/profile.js'); ?>

    <?php echo JsValidator::formRequest('Vanguard\Http\Requests\User\CreateUserRequest', '#user-form'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/user/add.blade.php ENDPATH**/ ?>