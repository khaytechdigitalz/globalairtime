<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="single-input">
            <label for="recipientsfname">Email</label>
            <input type="email"
            id="email"
           name="email"
           placeholder="<?php echo app('translator')->get('Email'); ?>"
           value="<?php echo e($edit ? $user->email : ''); ?>">                                                   </div>
    </div>
    <div class="col-md-6">
        <div class="single-input">
            <label for="recipientslname">Username</label>
            <input type="text"
            id="username"
           placeholder="(<?php echo app('translator')->get('optional'); ?>)"
           name="username"
           value="<?php echo e($edit ? $user->username : ''); ?>">
        </div>
    </div>
    <div class="col-md-12">
        <div class="single-input">
            <label for="password"><?php echo e($edit ? __("New Password") : __('Password')); ?></label>
            <input type="password"
                    id="password"
                   name="password"
                   <?php if($edit): ?> placeholder="<?php echo app('translator')->get("Leave field blank if you don't want to change it"); ?>" <?php endif; ?>>
        </div>
    </div>

    <div class="col-md-12">
        <div class="single-input">
            <label for="password_confirmation"><?php echo e($edit ? __("Confirm New Password") : __('Confirm Password')); ?></label>
            <input type="password"
             id="password_confirmation"
            name="password_confirmation"
            <?php if($edit): ?> placeholder="<?php echo app('translator')->get("Leave field blank if you don't want to change it"); ?>" <?php endif; ?>>
        </div>
    </div>
</div>

 
<?php if($edit): ?>
    <button type="submit" class="cmn-btn w-100" id="update-login-details-btn">
         
        <?php echo app('translator')->get('Update Details'); ?>
    </button>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/user/partials/auth.blade.php ENDPATH**/ ?>