<?php $__env->startSection('page-title', __('Users')); ?>
<?php $__env->startSection('page-heading', __('Users')); ?>


<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- Dashboard Section start -->
    <section class="dashboard-section body-collapse transactions">
        <div class="overlay pt-120">
            <div class="container-fruid">
                <div class="head-area">
                    <div class="row">
                        <div class="col-lg-5 col-md-4">
                            <h4>Manage Users</h4>
                        </div>
                        <div class="col-lg-7 col-md-8">
                            <div class="transactions-right d-flex align-items-center">
                                   
                                <?php if(Request::has('search') && Request::get('search') != ''): ?>
                                    <a href="<?php echo e(route('users.index')); ?>"
                                           class="btn btn-light d-flex align-items-center text-muted"
                                           role="button">
                                        <i class="fas fa-times"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="transactions-main">
                            <div class="top-items">
                                <h6>All Users</h6>
                                <div class="export-area">
                                    <ul class="d-flex align-items-center">
                                        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary btn-rounded float-right">
                                            <i class="fas fa-plus mr-2"></i>
                                            <?php echo app('translator')->get('Add User'); ?>
                                        </a> 
                                    </ul>
                                </div>
                            </div>
                            <form action="" method="GET" id="users-form" class="flex-fill">

                            <div class="filters-item">
                                <div class="single-item">
                                         <input type="text"
                                        name="search"
                                        value="<?php echo e(Request::get('search')); ?>"
                                        placeholder="<?php echo app('translator')->get('Search for users...'); ?>">
                                 </div>
                                
                                <div class="single-item">
                                    <?php echo Form::select(
                                            'status',
                                            $statuses,
                                            Request::get('status'),
                                            ['id' => 'status', 'class' => 'form-control input-solid']
                                        ); ?>

                                </div>
                                <div class="single-item">
                                <?php if(Request::has('search') && Request::get('search') != ''): ?>
                                    <a href="<?php echo e(route('users.index')); ?>"
                                           class="btn btn-light d-flex align-items-center text-muted"
                                           role="button">
                                        <i class="fas fa-times"></i>
                                    </a>
                                <?php endif; ?>
                                </div>
                            </div>
                        </form>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Name/ Business</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($users)): ?>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $__env->make('user.partials.row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="7"><em><?php echo app('translator')->get('No records found.'); ?></em></td>
                                        </tr>
                                    <?php endif; ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            <nav aria-label="Page navigation" class="d-flex justify-content-center mt-40">
                            <?php echo $users->render(); ?>

                             </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Dashboard Section end -->

 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $("#status").change(function () {
            $("#users-form").submit();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/user/list.blade.php ENDPATH**/ ?>