<script>
    var read_announcements_endpoint = "<?php echo e(route('announcements.read')); ?>";
</script>
<script src="<?php echo e(url("vendor/plugins/announcements/js/announcements.js")); ?>"></script>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/vendor/vanguardapp/announcements/src/../resources/views/partials/scripts.blade.php ENDPATH**/ ?>