<?php $__env->startSection('page-title', __('Reset Password')); ?>

<?php $__env->startSection('content'); ?>


    <!-- Email start -->
    <section class="login-reg">
        <div class="overlay pt-120">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-xl-6 order-xl-0 order-1">
                        
                        <div class="sec-img d-rtl">
                            <img 
                            style=" width: auto;
                            max-height: 100%;
                            max-width: 100%;"
                            src="<?php echo e(url('public/frontend/images/integrations-features-2.png')); ?>" class="max-un" alt="image">
                        </div>
                    </div>
                    <div class="col-xl-5">
                       
                        <div class="text-center">
                            <a href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(url('public/assets/img/vanguard-logo.png')); ?>" width="100" alt="<?php echo e(setting('app_name')); ?>" height="50">
                             </a>
                        </div>
                       
                        <div class="card mt-5">
                            <div class="card-body">
                                <h5 class="card-title text-center mt-4 mb-2 text-uppercase">
                                    <?php echo app('translator')->get('Forgot Your Password?'); ?>
                                </h5>
                    
                                <div class="p-4">
                                    <form role="form" action="<?= route('password.email') ?>" method="POST" id="remind-password-form" autocomplete="off">
                                        <?php echo e(csrf_field()); ?>

                    
                                        <p class="text-muted mb-4 text-center font-weight-light">
                                            <?php echo app('translator')->get('Please provide your email below and we will send you a password reset link.'); ?>
                                        </p>
                    
                                        <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                                        <div class="form-group password-field my-3">
                                            <label for="password" class="sr-only"><?php echo app('translator')->get('Email'); ?></label>
                                            <input type="email"
                                                   name="email"
                                                   id="email"
                                                   placeholder="<?php echo app('translator')->get('Your E-Mail'); ?>">
                                        </div>
                    
                                        <div class="form-group mt-4">
                                            <button type="submit" class="cmn-btn w-100 btn btn-primary btn-lg btn-block" id="btn-reset-password">
                                                <?php echo app('translator')->get('Reset Password'); ?>
                                            </button>
                                        </div>
                                        <p class="dont-acc">Have an account? <a href="<?php echo e(url('login')); ?>">Login</a></p>
                    
                                    </form>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
    </section>
 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo JsValidator::formRequest('Vanguard\Http\Requests\Auth\PasswordRemindRequest', '#remind-password-form'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>