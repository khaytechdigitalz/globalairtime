<?php $__env->startSection('page-title', __('My Profile')); ?>
<?php $__env->startSection('page-heading', __('My Profile')); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item active">
        <?php echo app('translator')->get('My Profile'); ?>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Dashboard Section start -->
    <section class="dashboard-section body-collapse account psay stesp exchange">
        
        <div class="overlay pt-120">
            <div class="container-fruid">
                <div class="main-content">
                    <div class="row">
                        
                        <div class="col-xxl-3 col-xl-4 col-md-6">
                            <div class="owner-details">
                                
                                <div class="owner-action">
                                   
                                  <div class="profile-area">
                                   
                                    <div class="name-area">
                                        <h6><?php echo e($user->username); ?></h6>
                                        <span class="badge badge-lg bg-<?php echo e($user->present()->labelClass); ?>">
                                            <?php echo e(trans("app.status.{$user->status}")); ?>

                                        </span>
                                    </div>
                                </div>
                                <div class="owner-info">
                                    <ul>
                                        <li>
                                            <p>Account ID:</p>
                                            <span class="mdr"><?php echo e($user->accountid); ?></span>
                                        </li>
                                        <li>
                                            <p>Joined:</p>
                                            <span class="mdr"><?php echo e($user->created_at->format(config('app.date_format'))); ?></span>
                                        </li> 
                                    </ul>
                                </div>

                                    <a href="javascript:void(0)">
                                        <img src="<?php echo e(url('public/backend/images/icon/logout.png')); ?>" alt="image">
                                        Logout
                                    </a>
                                    <a href="javascript:void(0)" class="delete">
                                        <img src="<?php echo e(url('public/backend/images/icon/delete-2.png')); ?>" alt="image">
                                        Delete Account
                                    </a>
                                </div>

                            </div>
                        </div>
                        <div class="col-xxl-9 col-xl-8">
                            <div class="tab-main">


                                <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <ul class="nav nav-tabs" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="account-tab" data-bs-toggle="tab"
                                            data-bs-target="#account" type="button" role="tab" aria-controls="account"
                                            aria-selected="true">Account</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="security-tab" data-bs-toggle="tab"
                                            data-bs-target="#security" type="button" role="tab" aria-controls="security"
                                            aria-selected="false">Security</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="avatar-tab" data-bs-toggle="tab"
                                            data-bs-target="#avatar" type="button" role="tab" aria-controls="avatar"
                                            aria-selected="false">Avatar</button>
                                    </li>
                                     
                                </ul>
                                <div class="tab-content mt-40">
                                    <div class="tab-pane fade show active" id="account" role="tabpanel"
                                        aria-labelledby="account-tab">
                                        <form action="<?php echo e(route('profile.update.details')); ?>" method="POST" id="details-form">
                                            <?php echo method_field('PUT'); ?>
                                            <?php echo csrf_field(); ?>
                                            <?php echo $__env->make('user.partials.details', ['profile' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </form>
                                    </div>
                                    <div class="tab-pane fade" id="avatar" role="tabpanel"
                                        aria-labelledby="avatar-tab">
                                        <form action="<?php echo e(route("profile.update.avatar")); ?>"
                                        method="POST"
                                        id="avatar-form"
                                        enctype="multipart/form-data">                  
                                          <?php echo csrf_field(); ?>
                                          <?php echo $__env->make('user.partials.avatar', ['updateUrl' => route('profile.update.avatar-external')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </form>
                                        
                                    </div>
                                    <div class="tab-pane fade" id="security" role="tabpanel"
                                        aria-labelledby="security-tab">
                                        <?php if(setting('2fa.enabled')): ?>
                                        <div class="single-content authentication d-flex align-items-center justify-content-between">
                                            <div class="left">
                                                <h5>Two Factor Authentication</h5>
                                                <p>Two-Factor Authentication (2FA) can be used to help protect your account</p>
                                            </div>
                                            <div class="right">
                                                <button>Enable</button>
                                            </div>
                                        </div>

                                            <div class="single-setting">
                                                 <div class="tab-pane fade px-2" id="2fa" role="tabpanel" aria-labelledby="nav-profile-tab">
                                                    <?php $route = Authy::isEnabled($user) ? 'disable' : 'enable'; ?>

                                                    <form action="<?php echo e(route("two-factor.{$route}")); ?>" method="POST" id="two-factor-form">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="user" value="<?php echo e($user->id); ?>">
                                                        <?php echo $__env->make('user.partials.two-factor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    </form>
                                                </div>
                                            </div>
                                         <?php endif; ?>
                                        
                                        <div class="change-pass mb-40">
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <h5>Change Password</h5>
                                                    <p>You can always change your password for security reasons or reset your password in case you forgot it.</p>
                                                    <a href="javascript:void(0)">Forgot password?</a>
                                                </div>
                                                <div class="col-sm-6">
                                                    <form action="<?php echo e(route('profile.update.login-details')); ?>"
                                                    method="POST"
                                                    id="login-details-form">
                                                    <?php echo method_field('PUT'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo $__env->make('user.partials.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </form>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                        
                                         
                                    </div>
                                     
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Dashboard Section end --> 
</section>
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo HTML::script('assets/js/as/btn.js'); ?>

    <?php echo HTML::script('assets/js/as/profile.js'); ?>

    <?php echo JsValidator::formRequest('Vanguard\Http\Requests\User\UpdateDetailsRequest', '#details-form'); ?>

    <?php echo JsValidator::formRequest('Vanguard\Http\Requests\User\UpdateProfileLoginDetailsRequest', '#login-details-form'); ?>


    <?php if(setting('2fa.enabled')): ?>
        <?php echo JsValidator::formRequest('Vanguard\Http\Requests\TwoFactor\EnableTwoFactorRequest', '#two-factor-form'); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/user/profile.blade.php ENDPATH**/ ?>