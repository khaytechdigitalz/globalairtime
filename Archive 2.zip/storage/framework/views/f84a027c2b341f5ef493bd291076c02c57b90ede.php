<?php $__env->startSection('page-title', __('Airtime')); ?>
<?php $__env->startSection('page-heading', __('Airtime')); ?> 

<?php $__env->startSection('content'); ?>

<?php $__env->startPush('style'); ?>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?php echo e(url('public/backend/css/widget.css')); ?>">
 <?php $__env->stopPush(); ?>

    <!-- Dashboard Section start -->
    <section class="dashboard-section body-collapse pay step step-3 crypto deposit-money">
        <div class="overlay pt-120">
            <div class="container-fruid">
                <div class="main-content">
                    <div class="head-area d-flex align-items-center justify-content-between">
                        <h5>Confirm Payment</h5>
                        <a href="<?php echo e(route('airtime')); ?>">
                        <div class="icon-area">
                            <img src="<?php echo e(url('public/backend/images/icon/support-icon.png')); ?>" alt="icon">
                        </div>
                        </a>
                    </div>
                    <div class="row justify-content-between pb-120">
                        <div class="col-xl-3 col-lg-4">
                            <div class="left-area">
                                <ul>
                                    <li><a href="javascript:void(0)" class="single-link active ">Beneficiary's Details</a></li>
                                    <li><a href="javascript:void(0)" class="single-link active">Enter amount</a></li>
                                    <li><a href="javascript:void(0)" class="single-link active last">Confirm Order</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-8 col-lg-8">
                            
                                <div class="payment-details">
                                    <div class="top-area">
                                        <h6>Confirm  transaction details</h6> 
                                    </div>
                                    <div class="row">
                                        <div class="col-xxl-8 col-xl-9 col-lg-12">
                                            <ul class="details-list">
                                                <li>
                                                    <span>Beneficiary's Phone</span>
                                                    <b><?php echo e(Session::get('bphone')); ?></b>
                                                </li>
                                                <li>
                                                    <span>Beneficiary's E-mail</span>
                                                    <b><a><?php echo e(Session::get('bemail')); ?></a></b>
                                                </li>
                                                <li>
                                                    <span>Network Provider</span>
                                                    <b><?php echo e(Session::get('operatorName')); ?></b>
                                                </li>
                                                <li>
                                                    <span>Country</span>
                                                    <b><?php echo e(Session::get('countryName')); ?></b>
                                                </li>
                                                <li>
                                                    <span>Continent</span>
                                                    <b><?php echo e(Session::get('countryContinent')); ?></b>
                                                </li>
                                                <li>
                                                    <span>Amount</span>
                                                    <b><?php echo e(Session::get('amount')); ?><small><?php echo e(Session::get('countryCurrency')); ?></small></b>
                                                </li> 
                                               
                                            </ul>

                                          
                                        </div>
                                      
                                    </div>
                                </div>
                               
                                <center><b class="text-danger" id="errorlog"></b></center>
                                <div class="footer-area mt-40"> 
                                    <input type="button" class="cmn-btn active" value="Proceed To Payment Page" onclick="Checkout.showPaymentPage();" />
                                </div>
                        
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Dashboard Section end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<script>
</script>
<?php $__env->stopPush(); ?>

<script src="https://ap.gateway.mastercard.com/static/checkout/checkout.min.js" data-error="errorCallback" data-cancel="cancelCallback"></script>
<script>
    function errorCallback(error) 
    {
        console.log('error', JSON.stringify(error));
        var reply = JSON.stringify(error)
        if(error.result == 'ERROR')
        {
        let respond = reply.replace("error.explanation", "message");
        var resp = JSON.parse(respond)
        document.getElementById("errorlog").innerHTML = resp.message;
        } 
    }
    function cancelCallback() {
        document.getElementById("errorlog").innerHTML = "Payment cancelled";
     }

    Checkout.configure({
        session: {
            id: '<?php echo e($sessionid); ?>'
        },
    });
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/bills/airtime/step3.blade.php ENDPATH**/ ?>