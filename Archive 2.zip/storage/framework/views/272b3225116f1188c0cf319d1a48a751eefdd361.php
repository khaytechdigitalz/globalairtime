<?php if(! Authy::isEnabled($user)): ?>
    <div class="alert alert-info">
        <?php echo app('translator')->get('In order to enable Two-Factor Authentication, you must install'); ?>
        <a target="_blank" href="https://www.authy.com/">Authy</a>
        <?php echo app('translator')->get('application on your phone'); ?>.
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="country_code"><?php echo app('translator')->get('Country Code'); ?></label>
                <input type="text"
                       class="form-control"
                       id="country_code"
                       placeholder="381"
                       name="country_code"
                       value="<?php echo e($user->two_factor_country_code); ?>">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="phone_number"><?php echo app('translator')->get('Cell Phone'); ?></label>
                <input type="text"
                       class="form-control"
                       id="phone_number"
                       placeholder="<?php echo app('translator')->get('Phone without country code'); ?>"
                       name="phone_number"
                       value="<?php echo e($user->two_factor_phone); ?>">
            </div>
        </div>
    </div>

    <button type="submit"
            class="btn btn-primary"
            data-toggle="loader"
            data-loading-text="<?php echo app('translator')->get('Enabling...'); ?>">
        <?php echo app('translator')->get('Enable'); ?>
    </button>
<?php else: ?>
    <button type="submit"
            class="btn btn-danger mt-2"
            data-toggle="loader"
            data-loading-text="<?php echo app('translator')->get('Disabling...'); ?>">
        <i class="fa fa-close"></i>
        <?php echo app('translator')->get('Disable'); ?>
    </button>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/user/partials/two-factor.blade.php ENDPATH**/ ?>