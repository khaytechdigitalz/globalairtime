<div class="upload-avatar">
    <div class="avatar-left d-flex align-items-center">
        <div class="profile-img">
            <img src="<?php echo e($edit ? $user->present()->avatar : url('public/assets/img/profile.png')); ?>" alt="image">
        </div>
        <div class="instraction">
            <h6>Your Avatar</h6>
            <p>Profile picture size: 400px x 400px</p>
        </div>
    </div>
    <div class="avatar-right">
        <div class="file-upload">
            <div class="right-area mb-4">
                <label class="file">
                    <input type="file" required name="avatar" >
                    <span class="file-custom"></span>
                </label>
            </div>
            <button type="submit" id="save-photo" class="cmn-btn w-100r">
                <?php echo app('translator')->get('Save'); ?>
            </button>
        </div>
    </div>
</div>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/user/partials/avatar.blade.php ENDPATH**/ ?>