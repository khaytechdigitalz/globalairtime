<?php $__env->startPush('style'); ?>
  <?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
 <?php $__env->stopPush(); ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="single-input">
            <label for="recipientsfname">First Name</label>
            <input type="text" id="first_name"
            name="first_name" placeholder="<?php echo app('translator')->get('First Name'); ?>" value="<?php echo e($edit ? $user->first_name : ''); ?>"/>                                                    
        </div>
    </div>
    <div class="col-md-6">
        <div class="single-input">
            <label for="recipientslname">Last Name</label>
            <input type="text"  id="last_name" name="last_name" placeholder="<?php echo app('translator')->get('Last Name'); ?>" value="<?php echo e($edit ? $user->last_name : ''); ?>"/>
        </div>
    </div>
    <div class="col-md-12">
        <div class="single-input">
            <label for="recipientslAddress">Date of Birth</label>
            <input type="text" name="birthday" id='birthday' value="<?php echo e($edit && $user->birthday ? $user->present()->birthday : ''); ?>"/>
        </div>
    </div>
    <div class="col-md-6">
        <div class="single-input">
            <label for="recipientslCity">Phone Number</label>
            <input type="text"  id="phone"
            name="phone" placeholder="<?php echo app('translator')->get('Phone'); ?>" value="<?php echo e($edit ? $user->phone : ''); ?>"/>
        </div>
    </div>
    <div class="col-md-6">
        <div class="single-input">
            <label for="recipientslCode">Address</label>
            <input type="text"  id="address" name="address" placeholder="<?php echo app('translator')->get('Address'); ?>" value="<?php echo e($edit ? $user->address : ''); ?>">
        </div>
    </div>
    <div class="col-md-12">
        <div class="single-input">
            <label for="recipientsphone">Country</label> 
            <?php echo Form::select('country_id', $countries, $edit ? $user->country_id : '', ['class' => '']); ?>

        </div>
    </div> 
    
    <div class="col-md-6">
        <div class="single-input">
            <label for="role_id">Role</label>
            <?php echo Form::select('role_id', $roles, $edit ? $user->role->id : '',['class' => ' ', 'id' => 'role_id', $profile ? 'disabled' : '']); ?>

        </div>
    </div>

    <div class="col-md-6">
        <div class="single-input">
            <label for="status">Status</label>
            <?php echo Form::select('status', $statuses, $edit ? $user->status : '',
['class' => '', 'id' => 'status', $profile ? 'disabled' : '']); ?>

        </div>
    </div>
    

    <?php if($edit): ?>
        <div class="col-md-12 mt-2">
            <button type="submit" class="cmn-btn w-100" id="update-details-btn">
                 <?php echo app('translator')->get('Update Details'); ?>
            </button>
        </div>
    <?php endif; ?>
</div>
 
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/user/partials/details.blade.php ENDPATH**/ ?>