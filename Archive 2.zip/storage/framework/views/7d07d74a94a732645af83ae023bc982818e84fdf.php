<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('page-title'); ?> - <?php echo e(setting('app_name')); ?></title>

    <link rel="shortcut icon" href="<?php echo e(url('public/backend/images/fav.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(url('public/backend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/backend/css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/backend/css/jquery-ui.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/backend/css/plugin/apexcharts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/backend/css/plugin/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/backend/css/arafat-font.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/backend/css/plugin/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/backend/css/style.css')); ?>">

    <?php echo $__env->yieldContent('styles'); ?>

    <?php if (\Vanguard\Plugins\Vanguard::hasHook('app:styles')) { 
                collect(\Vanguard\Plugins\Vanguard::getHookHandlers('app:styles'))
                    ->each(function ($hook) {
                        echo resolve($hook)->handle();
                    });
            } ?>
</head>
 
<body>
    <!-- start preloader -->
    <div class="preloader" id="preloader"></div>
    <!-- end preloader -->

    <!-- Scroll To Top Start-->
    <a href="javascript:void(0)" class="scrollToTop"><i class="fas fa-angle-double-up"></i></a>
    <!-- Scroll To Top End -->

    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            
                <main role="main" class="px-4">
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            


    <!--==================================================================-->
    <script src="<?php echo e(url('public/backend/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/backend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/backend/js/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(url('public/backend/js/plugin/apexcharts.js')); ?>"></script>
    <script src="<?php echo e(url('public/backend/js/plugin/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/backend/js/plugin/waypoint.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/backend/js/plugin/wow.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/backend/js/plugin/plugin.js')); ?>"></script>
    <script src="<?php echo e(url('public/backend/js/main.js')); ?>"></script>
    <script src="<?php echo e(url('public/assets/js/vendor.js')); ?>"></script>
    <script src="<?php echo e(url('public/assets/js/as/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>

    <?php if (\Vanguard\Plugins\Vanguard::hasHook('app:scripts')) { 
                collect(\Vanguard\Plugins\Vanguard::getHookHandlers('app:scripts'))
                    ->each(function ($hook) {
                        echo resolve($hook)->handle();
                    });
            } ?>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/layouts/backend.blade.php ENDPATH**/ ?>