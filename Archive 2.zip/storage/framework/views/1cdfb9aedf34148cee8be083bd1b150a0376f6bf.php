<?php $__env->startSection('page-title', trans('Login')); ?>

<?php $__env->startSection('content'); ?>

    <!-- Login Reg start -->
    <section class="login-reg">
        <div class="overlay pt-120">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-xl-6 order-xl-0 order-1">
                        <div class="sec-img d-rtl">
                            <img 
                            style=" width: auto;
                            max-height: 100%;
                            max-width: 100%;"
                            src="<?php echo e(url('public/frontend/images/login.png')); ?>" class="max-un" alt="image">
                        </div>
                    </div>
                    <div class="col-xl-5">
                        
                            <div class="text-center">
                                <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(url('public/assets/img/vanguard-logo.png')); ?>" width="100" alt="<?php echo e(setting('app_name')); ?>" height="50">
                                </a>
                            </div>
                            
                        <div class="section-text text-center">
                            <br>
                            <h5 class="sub-title">Log in to Continue</h5>
                           
                        </div>
                        <form role="form" action="<?= url('login') ?>" method="POST" id="login-form" autocomplete="off" class="mt-3">
                            <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <input type="hidden" value="<?= csrf_token() ?>" name="_token">
                            <?php if(Request::has('to')): ?>
                                <input type="hidden" value="<?php echo e(Request::get('to')); ?>" name="to">
                            <?php endif; ?>

                            <div class="row">
                                <div class="col-12">
                                    <div class="single-input">
                                        <label for="username" class="sr-only"><?php echo app('translator')->get('Email or Username'); ?></label>
                                        <input type="text"
                                                name="username"
                                                id="username"
                                                placeholder="<?php echo app('translator')->get('Email or Username'); ?>"
                                                value="<?php echo e(old('username')); ?>">
                                    </div>
                                    <div class="single-input">
                                        <label for="password" class="sr-only"><?php echo app('translator')->get('Password'); ?></label>
                                        <small><a href="<?php echo e(route('password.request')); ?>">Forgot Password ?</a></small>

                                        <input type="password"
                                            name="password"
                                            id="password"
                                            placeholder="<?php echo app('translator')->get('Password'); ?>">
                                     </div>
                                    <?php if(setting('remember_me')): ?>
                                        <div class="custom-control custom-checkbox single-input">
                                            <input type="checkbox" class="custom-control-input" name="remember" id="remember" value="1"/>
                                            <label class="custom-control-label font-weight-normal" for="remember">
                                                <?php echo app('translator')->get('Remember me?'); ?>
                                            </label>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <button type="submit" class="cmn-btn w-100" id="btn-login"><?php echo app('translator')->get('Log In'); ?></button>
                                </div>
                            <p class="dont-acc">Don’t have an account? <a href="<?php echo e(url('register')); ?>">Sign up</a></p>
                            <span class="or">Or </span>
                                <?php echo $__env->make('auth.social.buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                             
                            </div>
                        </form>
                       
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Login Reg end -->
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo HTML::script('assets/js/as/login.js'); ?>

    <?php echo JsValidator::formRequest('Vanguard\Http\Requests\Auth\LoginRequest', '#login-form'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/auth/login.blade.php ENDPATH**/ ?>