<?php $__env->startSection('page-title', __('Airtime')); ?>
<?php $__env->startSection('page-heading', __('Airtime')); ?> 

<?php $__env->startSection('content'); ?>

<?php $__env->startPush('style'); ?>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?php echo e(url('public/backend/css/widget.css')); ?>">
 <?php $__env->stopPush(); ?>
   
    <!-- Dashboard Section start -->
    <section class="dashboard-section body-collapse pay step crypto deposit-money">
        <div class="overlay pt-120">
            <div class="container-fruid">
                <div class="main-content">
                    <div class="head-area d-flex align-items-center justify-content-between">
                        <h5>Buy Airtime</h5>
                        <div class="icon-area">
                            <img src="<?php echo e(url('public/backend/images/icon/support-icon.png')); ?>" alt="icon">
                        </div>
                    </div>
                    <div class="row justify-content-between pb-120">
                        <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="col-xl-3 col-lg-4 col-md-5">
                            <div class="left-area">
                                <ul>
                                    <li><a href="javascript:void(0)" class="single-link active">Beneficiary's Details</a></li>
                                    <li><a href="javascript:void(0)" class="single-link two">Enter amount</a></li>
                                    <li><a href="javascript:void(0)" class="single-link last">Confirm Order</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-9 col-lg-8 col-md-7">
                            <div class="table-area">
                                <div class="head-area">
                                    <h6>Enter Beneficiary's Details</h6>
                                </div>
                                <div class="">
                                    <form  action="<?php echo e(route('airtime.step1')); ?>"  method="post" enctype="multipart/form-data" onsubmit="return submitUserForm();">
                                     <?php echo csrf_field(); ?>                                    <div class="row justify-content-center">
                                            <div class="col-md-12 mb-3">
                                                <div class="single-input">
                                                    <label for="cardNumber">Email Address</label>
                                                    <input type="email" id="email" name="email" placeholder="example@mail.com">
                                                </div>
                                            </div>
                                            <div class="col-md-12 mb-3">
                                                <div class="single-input">
                                                    <label for="cardHolder">Phone Number</label>
                                                    <input type="tel" id="tel" name="tel" placeholder="+2348012345678">
                                                </div>
                                            </div> 
                                            <div class="col-12">
                                                <div class="btn-border w-100">
                                                    <button type="submit" class="cmn-btn w-100">Proceed</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Dashboard Section end -->
 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php $__currentLoopData = \Vanguard\Plugins\Vanguard::availableWidgets(auth()->user()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(method_exists($widget, 'scripts')): ?>
            <?php echo app()->call([$widget, 'scripts']); ?>

        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/bills/airtime/index.blade.php ENDPATH**/ ?>