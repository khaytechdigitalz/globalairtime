<div class="side-items">
      
    <div class="single-item">
        <div class="section-text d-flex align-items-center justify-content-between">
            <h6> <?php echo app('translator')->get('Latest Registrations'); ?></h6>
            <div class="view-all d-flex align-items-center">
                <a href="<?php echo e(route('users.index')); ?>">View All</a>
                <img src="<?php echo e(url('public/backend/images/icon/right-arrow.png')); ?>" alt="icon">
            </div>
        </div>
        <?php if(count($latestRegistrations)): ?>
        <ul class="recipients-item">
            <?php $__currentLoopData = $latestRegistrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <p class="left d-flex align-items-center">
                    <img src="<?php echo e($user->present()->avatar); ?>" alt="icon">
                    <span class="info">
                        <span><?php echo e($user->present()->nameOrEmail); ?></span>
                        <span><?php echo e($user->created_at->diffForHumans()); ?></span>
                    </span>
                </p>
                <p class="right">
                    <a href="<?php echo e(route('users.show', $user)); ?>">
                    <span> View</span>
                     </a>
                </p>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
             
        </ul>
        <?php else: ?>
        <p class="text-muted"><?php echo app('translator')->get('No records found.'); ?></p>
        <?php endif; ?>
    </div>
</div>
 <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/plugins/dashboard/widgets/latest-registrations.blade.php ENDPATH**/ ?>