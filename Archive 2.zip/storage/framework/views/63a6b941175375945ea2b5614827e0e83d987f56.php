
    <!-- header-section start -->
    <header class="header-section">
        <div class="overlay">
            <div class="container">
                <div class="row d-flex header-area">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(url('public/assets/img/vanguard-logo.png')); ?>" width="100" class="logo" alt="logo">
                        </a>
                        <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbar-content">
                            <i class="fas fa-bars"></i>
                        </button>
                        <div class="collapse navbar-collapse justify-content-end" id="navbar-content">
                            <ul class="navbar-nav mr-auto mb-2 mb-lg-0">
                                
                                <li class="nav-item main-navbar">
                                    <a class="nav-link" href="<?php echo e(route('home')); ?>" data-bs-auto-close="outside">Home</a>
                                </li>
                                <li class="nav-item main-navbar">
                                    <a class="nav-link" href="<?php echo e(route('home')); ?>" data-bs-auto-close="outside">About</a>
                                </li>

                                <li class="nav-item main-navbar">
                                    <a class="nav-link" href="<?php echo e(route('home')); ?>" data-bs-auto-close="outside">Contact</a>
                                </li>
                                 
                            </ul>
                            <div class="right-area header-action d-flex align-items-center max-un">
                                <?php if(auth()->guard()->check()): ?>
                                <a href="<?php echo e(route('auth.logout')); ?>" class="login">Logout</a>
                                <a href="<?php echo e(route('dashboard')); ?>" class="cmn-btn">Account
                                    <i class="icon-d-right-arrow-2"></i>
                                </a>
                                <?php else: ?>
                                <a href="<?php echo e(url("login")); ?>" class="login">Login</a>
                                <a href="<?php echo e(url("register")); ?>" class="cmn-btn">Sign Up
                                    <i class="icon-d-right-arrow-2"></i>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- header-section end -->
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/partials/header.blade.php ENDPATH**/ ?>