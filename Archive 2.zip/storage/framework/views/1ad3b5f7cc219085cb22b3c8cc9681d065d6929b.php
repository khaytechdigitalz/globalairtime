<?php $__env->startSection('page-title', __('Sign Up')); ?>

<?php if(setting('registration.captcha.enabled')): ?>
    <script src='https://www.google.com/recaptcha/api.js'></script>
<?php endif; ?>

<?php $__env->startSection('content'); ?>


    <!-- Login Reg start -->
    <section class="login-reg">
        <div class="overlay pt-120">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-xl-6 order-xl-0 order-1">
                        <div class="sec-img d-rtl">
                            <img 
                            style=" width: auto;
                            max-height: 100%;
                            max-width: 100%;"
                            src="<?php echo e(url('public/frontend/images/register.png')); ?>" class="max-un" alt="image">
                        </div>
                    </div>
                    <div class="col-xl-5">
                       
                            <div class="text-center">
                                <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(url('public/assets/img/vanguard-logo.png')); ?>" width="100" alt="<?php echo e(setting('app_name')); ?>" height="50">
                                </a>
                            </div>
                        
                        <div class="section-text text-center">
                            <br>
                            <h5 class="sub-title">Welcome to <?php echo e(setting('app_name')); ?></h5>
                           
                        </div>
                        <form role="form" action="<?= url('register') ?>" method="post" id="registration-form" autocomplete="off" class="mt-3">
                            <input type="hidden" value="<?= csrf_token() ?>" name="_token">
                   
                            <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <input type="hidden" value="<?= csrf_token() ?>" name="_token">
                            

                            <div class="row">
                                <div class="col-12">
                                    <div class="single-input">
                                        <label for="username" class="sr-only"><?php echo app('translator')->get('Email or Username'); ?></label>
                                        <input type="email"
                                            name="email"
                                            id="email"
                                             placeholder="<?php echo app('translator')->get('Email'); ?>"
                                            value="<?php echo e(old('email')); ?>">
                                    </div>
                                    <div class="single-input">
                                        <label for="username" class="sr-only"><?php echo app('translator')->get('Username'); ?></label>
                                        <input type="text"
                                        name="username"
                                        id="username"
                                         placeholder="<?php echo app('translator')->get('Username'); ?>"
                                        value="<?php echo e(old('username')); ?>">
                                     </div>

                                    <div class="single-input">
                                        <label for="password" class="sr-only"><?php echo app('translator')->get('Password'); ?></label>
                                        <input type="password"
                                        name="password"
                                        id="password"
                                         placeholder="<?php echo app('translator')->get('Password'); ?>">
                                     </div>

                                     <div class="single-input">
                                        <label for="password_confirmation" class="sr-only"><?php echo app('translator')->get('Confirm Password'); ?></label>
                                        <input type="password"
                                        name="password_confirmation"
                                        id="password_confirmation"
                                         placeholder="<?php echo app('translator')->get('Confirm Password'); ?>">
                                     </div>
                                     <?php if(setting('tos')): ?>
                                     <div class="custom-control custom-checkbox">
                                         <input type="checkbox" class="custom-control-input" name="tos" id="tos" value="1"/>
                                         <label class="custom-control-label font-weight-normal" for="tos">
                                             <?php echo app('translator')->get('I accept'); ?>
                                             <a href="#tos-modal" data-bs-toggle="modal"><?php echo app('translator')->get('Terms of Service'); ?></a>
                                         </label>
                                     </div>
                                    <?php endif; ?>
                                    
                                    <?php if(setting('registration.captcha.enabled')): ?>
                                        <div class="form-group my-4">
                                            <?php echo app('captcha')->display(); ?>

                                        </div>
                                    <?php endif; ?>
                                    
                                    
                                    <button type="submit" class="cmn-btn w-100" id="btn-login"><?php echo app('translator')->get('Register'); ?></button>
                                </div>
                            <p class="dont-acc">Have an account? <a href="<?php echo e(url('login')); ?>">Login</a></p>
                            <span class="or">Or </span>
                                <?php echo $__env->make('auth.social.buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                             
                            </div>
                        </form>
                       
                    </div>
                </div>
            </div>
        </div>
        <?php if(setting('tos')): ?>
        <div class="modal fade" id="tos-modal" tabindex="-1" role="dialog" aria-labelledby="tos-label">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="tos-label"><?php echo app('translator')->get('Terms of Service'); ?></h5>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <?php echo $__env->make('auth.tos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <?php echo app('translator')->get('Close'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    </section>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo JsValidator::formRequest('Vanguard\Http\Requests\Auth\RegisterRequest', '#registration-form'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/auth/register.blade.php ENDPATH**/ ?>