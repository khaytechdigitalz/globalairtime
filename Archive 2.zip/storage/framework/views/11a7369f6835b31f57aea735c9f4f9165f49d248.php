
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/vendor/vanguardapp/activity-log/src/../resources/views/widgets/user-activity.blade.php ENDPATH**/ ?>