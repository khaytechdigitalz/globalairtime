<?php $__env->startSection('page-title', __('General Settings')); ?>
<?php $__env->startSection('page-heading', __('General Settings')); ?>


<?php $__env->startSection('content'); ?>


    <?php echo Form::open(['route' => 'settings.general.update', 'id' => 'general-settings-form']); ?>

    <section class="dashboard-section body-collapse pay step exchange">
        <div class="overlay pt-120">
            <div class="container-fruid">
                <div class="main-content">

                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <div class="card-body">
                                <div class="form-group mb-3">
                                    <label for="name"><?php echo app('translator')->get('Name'); ?></label>
                                    <input type="text" class="form-control input-solid" id="app_name" name="app_name"
                                        value="<?php echo e(setting('app_name')); ?>">
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="cmn-btn">
                        <?php echo app('translator')->get('Update'); ?>
                    </button>

                </div>
            </div>
        </div>
    </section>
    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/settings/general.blade.php ENDPATH**/ ?>