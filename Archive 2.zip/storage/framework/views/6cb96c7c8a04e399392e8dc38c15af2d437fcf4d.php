<link media="all"
      type="text/css"
      rel="stylesheet"
      href="<?php echo e(url(mix('/css/announcements.css', 'vendor/plugins/announcements'))); ?>">
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/vendor/vanguardapp/announcements/src/../resources/views/partials/styles.blade.php ENDPATH**/ ?>