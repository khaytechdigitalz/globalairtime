<div class="sidebar-wrapper">
    <div class="close-btn">
        <i class="fa-solid fa-xmark"></i>
    </div>
    <div class="sidebar-logo">
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(url('public/assets/img/vanguard-logo.png')); ?>" width="100" class="logo" alt="logo">
        </a>
    </div>
    <ul>
        <?php if(app('impersonate')->isImpersonating()): ?>
        <li class="">
            <a href="<?php echo e(route('impersonate.leave')); ?>">
                <img src="<?php echo e(url('public/backend/images/icon/dashboard.png')); ?>" alt="Dashboard"> <span>Exit</span>
            </a>
        </li> 
        <?php endif; ?>
        <?php $__currentLoopData = \Vanguard\Plugins\Vanguard::availablePlugins(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plugin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('partials.sidebar.items', ['item' => $plugin->sidebar()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
    </ul>
    <ul class="bottom-item">
        <?php if(config('session.driver') == 'database'): ?>

        <li>
            <a href="<?php echo e(route('profile.sessions')); ?>">
                <img src="<?php echo e(url('public/backend/images/icon/transactions.png')); ?>" alt="<?php echo app('translator')->get('My Sessions'); ?>"> <span><?php echo app('translator')->get('My Sessions'); ?></span>
            </a>
        </li> 
        <?php endif; ?>
        <li>
            <a href="<?php echo e(route('profile.activity')); ?>">
                <img src="<?php echo e(url('public/backend/images/icon/exchange.png')); ?>" alt="<?php echo app('translator')->get('My Activities'); ?>"> <span><?php echo app('translator')->get('My Activities'); ?></span>
            </a>
        </li> 
        
        <li>
            <a href="<?php echo e(route('auth.logout')); ?>">
                <img src="<?php echo e(url('public/backend/images/icon/quit.png')); ?>" alt="Quit"> <span>Logout</span>
            </a>
        </li>
    </ul>
    <div class="pt-120">
        <div class="invite-now">
            <div class="img-area">
                <img src="<?php echo e(url('public/frontend/images/invite.png')); ?>" alt="Image">
            </div>
            <p>Invite your friend and get $25</p>
            <a href="javascript:void(0)" class="cmn-btn">Invite Now</a>
        </div>
    </div>
</div>


<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/partials/sidebar/main.blade.php ENDPATH**/ ?>