
    <!-- header-section start -->
    <header class="header-section body-collapse">
        <div class="overlay">
            <div class="container-fruid">
                <div class="row d-flex header-area">
                    <div class="navbar-area d-flex align-items-center justify-content-between">
                        <div class="sidebar-icon">
                            <img src="<?php echo e(url('public/backend/images/icon/menu.png')); ?>" alt="icon">
                        </div>
                        <form action="#" class="flex-fill">
                            <div class="form-group d-flex align-items-center">
                                <img src="<?php echo e(url('public/backend/images/icon/search.png')); ?>" alt="icon">
                                <input type="text" placeholder="Type to search...">
                            </div>
                        </form>
                        <div class="dashboard-nav">
                            <div class="single-item language-area">
                                <div class="language-btn">
                                    <img src="<?php echo e(url('public/backend/images/icon/lang.png')); ?>" alt="icon">
                                </div>
                                <ul class="main-area language-content"> 
                                    <li class="active">English (US)</li> 
                                </ul>
                            </div>
                            <div class="single-item notifications-area">
                                <div class="notifications-btn">
                                    <img src="<?php echo e(url('public/backend/images/icon/bell.png')); ?>" class="bell-icon" alt="icon">
                                </div>
                                <div class="main-area notifications-content">
                                    <div class="head-area d-flex justify-content-between">
                                        <h5>Notifications</h5>
                                        <span class="mdr">4</span>
                                    </div>
                                    <ul>
                                        
                                    </ul>
                                </div>
                            </div>
                            <div class="single-item user-area">
                                <div class="profile-area d-flex align-items-center">
                                    <span class="user-profile">
                                        <img src="<?php echo e(auth()->user()->present()->avatar); ?>" alt="User">
                                    </span>
                                    <i class="fa-solid fa-sort-down"></i>
                                </div>
                                <div class="main-area user-content">
                                    <div class="head-area d-flex align-items-center">
                                        <div class="profile-img">
                                            <img src="<?php echo e(url('public/upload/users/')); ?>/<?php echo e(auth()->user()->avatar); ?>" alt="User">
                                        </div>
                                        <div class="profile-head">
                                            <a href="javascript:void(0)">
                                                <h5><?php echo e(auth()->user()->present()->nameOrEmail); ?></h5>
                                                
                                            </a>
                                            <p class="wallet-id">Account ID: <?php echo e(auth()->user()->present()->accountid); ?></p>
                                        </div>
                                    </div>
                                    <ul>
                                        <li class="border-area">
                                            <a href="<?php echo e(route('profile')); ?>"><i class="fas fa-cog"></i>Settings</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('auth.logout')); ?>"><i class="fas fa-sign-out"></i>Logout</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo $__env->make('partials.sidebar.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    
                </div>
            </div>
        </div>
    </header>
    <!-- header-section end -->


<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/usermanager/resources/views/partials/navbar.blade.php ENDPATH**/ ?>