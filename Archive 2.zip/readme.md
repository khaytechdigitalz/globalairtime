## Vanguard - Advanced PHP Login and User Management

- Website: https://vanguardapp.io
- Documentation: https://milos.support-hub.io
- Developed by [Milos Stojanovic](https://mstojanovic.net)