<div class="gradient-style1 text-white box-shadow border-radius-10 height-100-p widget-style3">
    <div class="d-flex flex-wrap align-items-center">
        <div class="widget-data">
            <div class="weight-400 font-20">@lang('Total Users')</div>
            <div class="weight-300 font-20">{{ number_format($count) }}</div>
        </div>
        <div class="widget-icon">
            <div class="icon"><i class="fa fa-user-plus" aria-hidden="true"></i></div>
        </div>
    </div>
</div>

 