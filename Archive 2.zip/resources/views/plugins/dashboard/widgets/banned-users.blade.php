<div class="gradient-style4 text-white box-shadow border-radius-10 height-100-p widget-style3">
    <div class="d-flex flex-wrap align-items-center">
        <div class="widget-data">
            <div class="weight-400 font-20">@lang('Banned Users')</div>
            <div class="weight-300 font-20">{{ number_format($count) }}</div>
        </div>
        <div class="widget-icon">
            <div class="icon"><i class="fa fa-user-slash" aria-hidden="true"></i></div>
        </div>
    </div>
</div>
{{--

<div class="card widget">
    <div class="card-body">
        <div class="row">
            <div class="p-3 text-danger flex-1">
                <i class="fa fa-user-slash fa-3x"></i>
            </div>

            <div class="pr-3">
                <h2 class="text-right">{{ number_format($count) }}</h2>
                <div class="text-muted">@lang('Banned Users')</div>
            </div>
        </div>
    </div>
</div>
--}}
