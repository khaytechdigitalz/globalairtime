<?php

namespace Vanguard\Events\Settings;

class Updated {}