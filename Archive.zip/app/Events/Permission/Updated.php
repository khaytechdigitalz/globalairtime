<?php

namespace Vanguard\Events\Permission;

class Updated extends PermissionEvent {}